<?php

$google_fonts = apply_filters('avf_google_heading_font', array(	__('Default', 'avia_framework') =>'',
	
						'Alice'=>'Alice',
						'Allerta'=>'Allerta',
						'Arvo'=>'Arvo',
						'Arimo'=>'Arimo:400,700',
						'Antic'=>'Antic',
	
						'Bangers'=>'Bangers',
						'Bitter'=>'Bitter',
	
						'Cabin'=>'Cabin',
						'Cardo'=>'Cardo',
						'Carme'=>'Carme',
						'Coda'=>'Coda',
						'Comfortaa'=>'Comfortaa:300,400,700',
						'Coustard'=>'Coustard',
						'Gruppo'=>'Gruppo',
	
						'Damion'=>'Damion',
						'Dancing Script'=>'Dancing Script',
						'Droid Sans'=>'Droid Sans',
						'Droid Serif'=>'Droid Serif',
	
						'EB Garamond'=>'EB Garamond',
						
						
						'Finger Paint'=>'Finger Paint',
						'Fjord One'=>'Fjord One',
	
	
						'Great Vibes'=>'Great Vibes',
						
						
						'Inconsolata'=>'Inconsolata',
	
						'Josefin Sans' => 'Josefin Sans',
						'Josefin Slab'=>'Josefin Slab',
	
						'Kameron'=>'Kameron',
						'Kreon'=>'Kreon',
	
						'Lato'=>'Lato:300,400,700',
						'Lobster'=>'Lobster',
						'Lora'=>'Lora',
						'League Script'=>'League Script',
	
						'Mate SC'=>'Mate SC',
						'Marck Script'=>'Marck Script',
						'Mako'=>'Mako',
						'Merriweather'=>'Merriweather',
						'Metrophobic'=>'Metrophobic',
						'Molengo'=>'Molengo',
						'Montserrat'=>'Montserrat',
						'Muli'=>'Muli',
	
						'Nobile'=>'Nobile',
						'News Cycle'=>'News Cycle',
	
						'Open Sans'=>'Open Sans:400,600',
						'Open Sans Condensed'=>'Open Sans Condensed:300,700',
						'Orbitron'=>'Orbitron',
						'Oswald'=>'Oswald',
	
						'Pacifico'=>'Pacifico',
						'Petit Formal Script'=>'Petit Formal Script',
						'Poly'=>'Poly',
						'Podkova'=>'Podkova',
						'PT Sans'=>'PT Sans',
	
						'Quattrocento'=>'Quattrocento',
						'Questrial'=>'Questrial',
						'Quicksand'=>'Quicksand',
	
						'Raleway'=>'Raleway',
						'Righteous' => 'Righteous',
						'Roboto' => 'Roboto',
						
						'Salsa'=>'Salsa',
						'Sunshiney'=>'Sunshiney',
						'Signika Negative'=>'Signika Negative',
	
	
						'Tangerine'=>'Tangerine',
						'Terminal Dosis'=>'Terminal Dosis',
						'Tenor Sans'=>'Tenor Sans',
	
						'Varela Round'=>'Varela Round',
	
						'Yellowtail'=>'Yellowtail',
	
	
						));
						
						
