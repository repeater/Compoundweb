<?php
// To
define("WEBMASTER_EMAIL", 'thecompoundinfo@gmail.com');
?>